wynik = 15*(3+4)-10
document.write("15*(3+4)-10="+wynik)