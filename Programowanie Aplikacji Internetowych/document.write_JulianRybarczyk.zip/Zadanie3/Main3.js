text1 = prompt("Wprowadź tekst pierwszy",) //Pierwsze okno dialogowe
text2 = prompt("Wprowadź tekst drugi",) //Drugie okno dialogowe
text3 = prompt("Wprowadź tekst trzeci",) //Trzecie okno dialogowe

document.write(text1 + "<br>" + text2 + "<br>" + text3) //Skrypt powodujący wyświetlenie na stronie tekstu podanego w oknach dialogowych 