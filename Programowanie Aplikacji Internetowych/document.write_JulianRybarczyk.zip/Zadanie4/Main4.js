answer = prompt("Co odpowiesz?",)
alert("Twoja odpowiedź to: "+answer) 