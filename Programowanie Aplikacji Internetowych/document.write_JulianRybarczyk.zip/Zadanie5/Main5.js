ImieNazwisko = prompt("Podaj imię i nazwisko:");
email = prompt("Podaj adres e-mail");
document.write("<b>Imię i nazwisko: </b><i>" + ImieNazwisko + "</i>" + "<br><b>Adres e-mail: </b>" + '<a style="text-decoration:none" href="mailto:'+ email + '")> <font color="#808080">' + email + '</font></a>');
//Na adres mailowy można kliknąć aby wysłać, aby wysłać na ten mail wiadommość ;)