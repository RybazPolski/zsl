<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Operatory</title>
</head>
<body>
    
    <form action="operatory.php" method="GET">
        <input type="text" placeholder="Wprowadź liczbę a" name="a">
        <input type="text" placeholder="Wprowadź liczbę b" name="b">
        <input type="text" placeholder="Wprowadź liczbę c" name="c">
        <input type="submit" name="button" value="Wyślij">
    </form>
    <br>

    <?php
        if(isset($_GET['a'])){
            $a = $_GET['a'];
        };
        if(isset($_GET['b'])){
            $b = $_GET['b'];
        };
        if(isset($_GET['c'])){
            $c = $_GET['c'];
        };

        

        if($b!==4){
            echo "(".$a."+6)/(".$b."-4)=".($a+6)/($b-4)."<br>";
        }else{
            echo "Nie można obliczyć.";
        };


        
        if($a>$b){
            if($a>$c){
                echo $a." jest największe";
            }else{
                echo $c." jest największe";
            }
        }elseif($b>$c){
            echo $b." jest największe";

        }else{
            echo $c." jest największe";
        }
    ?>



</body>
</html>