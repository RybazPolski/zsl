//alert("Cześć");

//if (confirm("Czy osoba jest pełnoletnia?")==true) {
//    alert("Osoba ma 18 lub więcej lat.")
//} else {
//    alert("Osoba ma mniej niż 18 lat.")
//}

//wiek = prompt("Podaj swój wiek",);
//alert("Masz " + wiek + " lat")