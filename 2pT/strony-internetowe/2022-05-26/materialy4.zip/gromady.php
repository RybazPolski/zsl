<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gromady kręgowców</title>
    <link rel="stylesheet" href="./style12.css">
</head>
<body>
    <div class="menu">
        <a href="./gromady-ryby.html">gromada ryb</a>
        <a href="./gromady-ptaki.html">gromada ptaków</a>
        <a href="./gromady-ssaki.html">gromada ssaków</a>
    </div>
    <div class="logo">
        <h2>GROMADY KRĘGOWCÓW</h2>
    </div>
    <div class="left">

    </div>
    <div class="right">
        <h1>PTAKI</h1>
        <ol>

        </ol>
        <img src="./materialy4/sroka.jpg" alt="Sroka zwyczajna, gromada ptaki">

    </div>
    <footer>Stronę o kręgowcach przygotował: Julian Rybarczyk</footer>
</body>
</html>